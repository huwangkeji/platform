/* PHP App发布/升级分发平台 V1.0 —— 后台管理单页应用 */
(function () {
  'use strict';

  var TOKEN_KEY = 'arp_admin_token';
  var ADMIN_KEY = 'arp_admin_info';
  var state = { token: '', admin: null, page: 'dashboard' };

  // ---------- 基础工具 ----------
  function esc(s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  }
  function fmtTime(s) {
    if (!s) return '-';
    return String(s).replace('T', ' ').slice(0, 19);
  }
  function fmtSize(b) {
    if (!b || b <= 0) return '-';
    var u = ['B', 'KB', 'MB', 'GB'], i = 0, n = b;
    while (n >= 1024 && i < u.length - 1) { n /= 1024; i++; }
    return n.toFixed(i === 0 ? 0 : 1) + ' ' + u[i];
  }
  function badge(status) {
    var map = {
      'published': ['layui-bg-green', '已发布'], 'gray': ['layui-bg-cyan', '灰度中'],
      'paused': ['layui-bg-orange', '已暂停'], 'rollback': ['layui-bg-red', '已回滚'],
      'testing': ['layui-bg-blue', '测试中'], 'pending': ['layui-bg-gray', '待发布'],
      'draft': ['layui-bg-gray', '草稿'], 'offline': ['layui-bg-black', '已下线'],
      'processing': ['layui-bg-blue', '处理中'], 'solved': ['layui-bg-green', '已解决'],
      'closed': ['layui-bg-gray', '已关闭'], 'open': ['layui-bg-orange', '待处理'],
      'disabled': ['layui-bg-gray', '停用'], 'active': ['layui-bg-green', '活跃'],
      'inactive': ['layui-bg-gray', '沉默'], 'full': ['layui-bg-green', '全量'],
      'gray_release': ['layui-bg-cyan', '灰度'], 'channel': ['layui-bg-blue', '渠道']
    };
    var m = map[status] || ['layui-bg-gray', status || '-'];
    return '<span class="layui-badge ' + m[0] + '">' + esc(m[1]) + '</span>';
  }

  // ---------- API ----------
  function api(method, url, data, multipart) {
    var opts = { method: method, headers: {} };
    if (state.token) opts.headers['Authorization'] = 'Bearer ' + state.token;
    if (data !== undefined && data !== null) {
      if (multipart) {
        opts.body = data;
      } else if (typeof data === 'string') {
        opts.headers['Content-Type'] = 'application/json';
        opts.body = data;
      } else {
        opts.headers['Content-Type'] = 'application/json';
        opts.body = JSON.stringify(data);
      }
    }
    return fetch('/api/v1/admin/' + url, opts).then(function (r) {
      return r.json().catch(function () { return { code: -1, message: '响应解析失败' }; });
    }).then(function (json) {
      if (json.code === 401) {
        App.logout(true);
        throw new Error('登录已过期，请重新登录');
      }
      if (json.code !== 0) throw new Error(json.message || '请求失败');
      return json.data;
    });
  }
  function toast(msg) { layer.msg(msg || '操作成功'); }
  function errMsg(e) { layer.msg(e && e.message ? e.message : '请求失败'); }
  // 弹窗内容为动态 HTML，打开后重渲染 layui 表单控件（switch/checkbox/select 依赖 form.render 才可交互）
  function openPanel(cfg) {
    layer.open(cfg);
    setTimeout(function () {
      try { if (window.layui && window.layui.form) window.layui.form.render(); } catch (e) {}
    }, 30);
  }

  // ---------- 表格渲染 ----------
  function renderTable(el, columns, rows, emptyText) {
    var html = '<table class="layui-table layui-table-hover"><thead><tr>';
    columns.forEach(function (c) { html += '<th style="' + (c.width ? 'width:' + c.width : '') + '">' + esc(c.title) + '</th>'; });
    html += '</tr></thead><tbody>';
    if (!rows || !rows.length) {
      html += '<tr><td colspan="' + columns.length + '" class="tbl-empty">' + esc(emptyText || '暂无数据') + '</td></tr>';
    } else {
      rows.forEach(function (row) {
        html += '<tr>';
        columns.forEach(function (c) {
          var v = c.render ? c.render(row[c.key], row) : row[c.key];
          html += '<td>' + (v === null || v === undefined ? '-' : v) + '</td>';
        });
        html += '</tr>';
      });
    }
    html += '</tbody></table>';
    el.innerHTML = html;
  }
  function pager(el, total, page, pageSize, cb) {
    if (!total || total <= pageSize) { el.innerHTML = '<div class="tbl-page-info">共 ' + total + ' 条</div>'; return; }
    var pages = Math.ceil(total / pageSize), html = '<div class="tbl-page">共 ' + total + ' 条，第 ' + page + '/' + pages + ' 页 ';
    if (page > 1) html += '<a class="layui-btn layui-btn-xs" data-p="' + (page - 1) + '">上一页</a> ';
    if (page < pages) html += '<a class="layui-btn layui-btn-xs" data-p="' + (page + 1) + '">下一页</a>';
    html += '</div>';
    el.innerHTML = html;
    el.querySelectorAll('a').forEach(function (a) {
      a.addEventListener('click', function () { cb(parseInt(a.dataset.p, 10)); });
    });
  }

  // ---------- 页面注册表 ----------
  var PAGES = {};

  // ---------- 控制台 ----------
  PAGES.dashboard = function (el) {
    api('GET', 'dashboard').then(function (d) {
      var cards = [
        { label: '应用总数', value: d.apps, icon: '📱' },
        { label: '版本总数', value: d.versions, icon: '📦' },
        { label: '设备总数', value: d.devices, icon: '📟' },
        { label: '今日下载', value: d.today_downloads, icon: '⬇️' },
        { label: '今日升级', value: d.today_updates, icon: '🔄' },
        { label: '今日反馈', value: d.today_feedbacks, icon: '🧾' },
        { label: '待处理反馈', value: d.pending_feedbacks, icon: '⏳' },
        { label: '待处理工单', value: d.pending_tickets, icon: '🎫' }
      ];
      var html = '<div class="stat-grid">';
      cards.forEach(function (c) {
        html += '<div class="stat-card"><div class="stat-icon">' + c.icon + '</div><div class="stat-value">' + c.value + '</div><div class="stat-label">' + c.label + '</div></div>';
      });
      html += '</div>';
      html += '<div class="layui-card"><div class="layui-card-header">近 7 日下载 / 升级趋势</div><div class="layui-card-body" id="trend-chart"><div class="loading">加载中…</div></div></div>';
      el.innerHTML = html;
      api('GET', 'dashboard/trend?days=7').then(function (t) {
        // 简单柱状图
        var days = (t.trend || []).map(function (x) { return String(x.date).slice(5); });
        var maxD = Math.max.apply(null, (t.trend || []).map(function (x) { return x.downloads; }).concat([1]));
        var maxU = Math.max.apply(null, (t.trend || []).map(function (x) { return x.updates; }).concat([1]));
        var chart = '<div class="bar-legend"><span>⬇️ 下载</span><span>🔄 升级</span></div><div class="bar-chart">';
        (t.trend || []).forEach(function (x, i) {
          chart += '<div class="bar-col"><div class="bar-row"><div class="bar bar-d" style="height:' + Math.max(2, Math.round(x.downloads / maxD * 120)) + 'px" title="下载 ' + x.downloads + '"></div>'
            + '<div class="bar bar-u" style="height:' + Math.max(2, Math.round(x.updates / maxU * 120)) + 'px" title="升级 ' + x.updates + '"></div></div>'
            + '<div class="bar-label">' + days[i] + '</div></div>';
        });
        chart += '</div>';
        document.getElementById('trend-chart').innerHTML = chart;
      }).catch(errMsg);

      api('GET', 'dashboard/charts').then(function (c) {
        var html2 = '<div class="chart-panels">';
        var panel = function (title, items, nameFn, valFn) {
          var max = Math.max.apply(null, items.map(function (x) { return valFn(x); }).concat([1]));
          var h = '<div class="layui-card"><div class="layui-card-header">' + title + '</div><div class="layui-card-body"><div class="hbar">';
          items.forEach(function (x) {
            h += '<div class="hbar-row"><span class="hbar-name">' + esc(nameFn(x)) + '</span><div class="hbar-track"><div class="hbar-fill" style="width:' + Math.round(valFn(x) / max * 100) + '%"></div></div><span class="hbar-val">' + valFn(x) + '</span></div>';
          });
          h += '</div></div></div>';
          return h;
        };
        html2 += panel('平台分布', c.platforms || [], function (x) { return x.name; }, function (x) { return x.value; });
        html2 += panel('渠道分布', c.channels || [], function (x) { return x.channel_code || '未知'; }, function (x) { return x.total; });
        html2 += panel('版本分布', c.versions || [], function (x) { return x.name; }, function (x) { return x.value; });
        html2 += panel('反馈类型', c.feedback_types || [], function (x) { return x.type || '-'; }, function (x) { return x.total; });
        html2 += '</div>';
        el.insertAdjacentHTML('beforeend', html2);
      }).catch(errMsg);
    }).catch(errMsg);
  };

  // ---------- 应用列表 ----------
  PAGES.apps = function (el) {
    var page = 1, pageSize = 15;
    function load() {
      api('GET', 'apps?page=' + page + '&page_size=' + pageSize).then(function (d) {
        var html = '<div class="toolbar"><button class="layui-btn layui-btn-sm" onclick="App.openAppForm()">➕ 新建应用</button></div>';
        el.innerHTML = html + '<div class="tbl-wrap" id="apps-table"></div><div id="apps-pager"></div>';
        renderTable(document.getElementById('apps-table'), [
          { title: 'ID', key: 'id', width: '60px' },
          { title: '应用', key: 'name', render: function (_, r) { return esc(r.name) + '<div class="sub">' + esc(r.code) + '</div>'; } },
          { title: '包名 / Bundle', key: 'package_name', render: function (v, r) { return '<div>' + esc(v || '-') + '</div><div class="sub">' + esc(r.bundle_id || '-') + '</div>'; } },
          { title: '当前版本', key: 'current_version', render: function (v) { return v ? esc(v.name) + ' <span class="sub">' + esc(v.status) + '</span>' : '-'; } },
          { title: '版本数', key: 'version_count', width: '80px' },
          { title: '状态', key: 'status', render: function (v) { return badge(v === 1 ? 'active' : 'disabled'); } },
          { title: '创建时间', key: 'created_at', render: fmtTime },
          { title: '操作', key: 'id', render: function (_, r) {
            var toggle = r.status === 1 ? 'onclick="App.toggleApp(' + r.id + ', 0)"' : 'onclick="App.toggleApp(' + r.id + ', 1)"';
            var toggleText = r.status === 1 ? '停用' : '启用';
            return '<div class="ops"><a class="layui-btn layui-btn-xs layui-btn-normal" href="#/versions?app=' + r.id + '">版本</a>'
              + '<a class="layui-btn layui-btn-xs" onclick="App.openAppForm(' + r.id + ')">编辑</a>'
              + '<a class="layui-btn layui-btn-xs layui-btn-warm" ' + toggle + '>' + toggleText + '</a></div>';
          } }
        ], d.list);
        pager(document.getElementById('apps-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 版本管理 ----------
  PAGES.versions = function (el) {
    var page = 1, pageSize = 15, filterApp = '';
    function load() {
      api('GET', 'versions?page=' + page + '&page_size=' + pageSize + (filterApp ? '&app_id=' + filterApp : '')).then(function (d) {
        var html = '<div class="toolbar">'
          + '<select id="ver-app-filter" class="layui-select-inline"><option value="">全部应用</option></select>'
          + '<button class="layui-btn layui-btn-sm" onclick="App.openUploadForm()">⬆️ 上传安装包</button></div>';
        el.innerHTML = html + '<div class="tbl-wrap" id="versions-table"></div><div id="versions-pager"></div>';
        var sel = document.getElementById('ver-app-filter');
        api('GET', 'apps?page=1&page_size=100').then(function (a) {
          (a.list || []).forEach(function (x) {
            var o = document.createElement('option');
            o.value = x.id; o.textContent = x.name;
            if (String(x.id) === filterApp) o.selected = true;
            sel.appendChild(o);
          });
        });
        sel.addEventListener('change', function () { filterApp = sel.value; page = 1; load(); });
        renderTable(document.getElementById('versions-table'), [
          { title: 'ID', key: 'id', width: '50px' },
          { title: '应用', key: 'app_name', render: esc },
          { title: '版本', key: 'version_name', render: function (v, r) { return '<strong>' + esc(v) + '</strong><div class="sub">code ' + esc(r.version_code) + ' · ' + esc(r.platform) + (r.architecture ? ' · ' + esc(r.architecture) : '') + '</div>'; } },
          { title: '类型', key: 'version_type', render: function (v) { return esc(v === 'beta' ? '内测' : v === 'rc' ? '候选' : '正式'); } },
          { title: '大小', key: 'file_size', render: fmtSize },
          { title: '强制升级', key: 'is_force_update', render: function (v, r) {
            var s = v === 1 ? '强制' : '提示';
            if (r.minimum_version_code) s += ' (最低 code ' + r.minimum_version_code + ')';
            return s;
          } },
          { title: '状态', key: 'status', render: badge },
          { title: '发布时间', key: 'published_at', render: fmtTime },
          { title: '操作', key: 'id', render: function (_, r) {
            var ops = '<div class="ops">';
            ops += '<a class="layui-btn layui-btn-xs layui-btn-normal" href="' + esc(r.last_release === 1 ? '/download/' + r.id : '#') + '" ' + (r.last_release === 1 ? 'target="_blank"' : 'onclick="App.publishVersion(' + r.id + ')"') + '>' + (r.last_release === 1 ? '下载' : '发布') + '</a>';
            if (r.status === 'published' || r.status === 'gray') {
              ops += '<a class="layui-btn layui-btn-xs layui-btn-warm" onclick="App.pauseVersion(' + r.id + ')">暂停</a>';
              ops += '<a class="layui-btn layui-btn-xs layui-btn-danger" onclick="App.rollbackVersion(' + r.id + ')">回滚</a>';
            }
            if (['draft', 'testing', 'paused'].indexOf(r.status) >= 0) {
              ops += '<a class="layui-btn layui-btn-xs" onclick="App.openVersionForm(' + r.id + ')">编辑</a>';
            }
            if (['draft', 'offline'].indexOf(r.status) >= 0) {
              ops += '<a class="layui-btn layui-btn-xs layui-btn-danger" onclick="App.deleteVersion(' + r.id + ')">删除</a>';
            }
            ops += '</div>';
            return ops;
          } }
        ], d.list);
        pager(document.getElementById('versions-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 发布任务 ----------
  PAGES.releases = function (el) {
    var page = 1, pageSize = 15;
    function load() {
      api('GET', 'releases?page=' + page + '&page_size=' + pageSize).then(function (d) {
        el.innerHTML = '<div class="tbl-wrap" id="releases-table"></div><div id="releases-pager"></div>';
        renderTable(document.getElementById('releases-table'), [
          { title: 'ID', key: 'id', width: '50px' },
          { title: '发布名称', key: 'name', render: esc },
          { title: '应用 / 版本', key: 'app_name', render: function (v, r) { return esc(v) + '<div class="sub">' + esc(r.version_name) + '</div>'; } },
          { title: '类型', key: 'release_type', render: function (v) { return badge(v); } },
          { title: '灰度比例', key: 'rollout_percent', render: function (v, r) { return r.release_type === 'full' ? '—' : v + '%'; } },
          { title: '状态', key: 'status', render: badge },
          { title: '开始时间', key: 'start_at', render: fmtTime },
          { title: '结束时间', key: 'end_at', render: fmtTime },
          { title: '创建人', key: 'creator_name', render: esc },
          { title: '规则', key: 'rules', render: function (v) {
            if (!v) return '-';
            var arr = typeof v === 'string' ? (function () { try { return JSON.parse(v); } catch (e) { return []; } })() : v;
            if (!arr || !arr.length) return '-';
            return esc(arr.map(function (x) { return (x.field || '') + (x.op || '') + (x.value || ''); }).join('，'));
          } }
        ], d.list);
        pager(document.getElementById('releases-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 反馈 ----------
  PAGES.feedbacks = function (el) {
    var page = 1, pageSize = 15;
    function load() {
      api('GET', 'feedbacks?page=' + page + '&page_size=' + pageSize).then(function (d) {
        el.innerHTML = '<div class="tbl-wrap" id="fb-table"></div><div id="fb-pager"></div>';
        renderTable(document.getElementById('fb-table'), [
          { title: 'ID', key: 'id', width: '50px' },
          { title: '应用', key: 'app_name', render: esc },
          { title: '标题', key: 'title', render: esc },
          { title: '类型', key: 'type', render: function (v) { return esc({ bug: 'Bug', suggestion: '建议', question: '咨询', other: '其他' }[v] || v); } },
          { title: '用户/设备', key: 'device_id', render: function (v) { return esc(v || '-'); } },
          { title: '版本', key: 'app_version', render: function (v) { return esc(v || '-'); } },
          { title: '状态', key: 'status', render: badge },
          { title: '时间', key: 'created_at', render: fmtTime },
          { title: '操作', key: 'id', render: function (_, r) {
            return '<div class="ops"><a class="layui-btn layui-btn-xs layui-btn-primary" onclick="App.viewFeedback(' + r.id + ')">详情</a></div>';
          } }
        ], d.list);
        pager(document.getElementById('fb-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 工单 ----------
  PAGES.tickets = function (el, query) {
    var page = 1, pageSize = 15, kw = (query && query.kw) ? decodeURIComponent(query.kw) : '';
    function load() {
      api('GET', 'tickets?page=' + page + '&page_size=' + pageSize + (kw ? '&keyword=' + encodeURIComponent(kw) : '')).then(function (d) {
        el.innerHTML = '<div class="tbl-wrap" id="tk-table"></div><div id="tk-pager"></div>';
        renderTable(document.getElementById('tk-table'), [
          { title: '单号', key: 'ticket_no', render: esc },
          { title: '标题', key: 'title', render: esc },
          { title: '应用', key: 'app_name', render: esc },
          { title: '优先级', key: 'priority', render: function (v) { return esc({ high: '高', medium: '中', low: '低' }[v] || v || '-'); } },
          { title: '状态', key: 'status', render: badge },
          { title: '负责人', key: 'assignee_name', render: function (v) { return esc(v || '-'); } },
          { title: '创建时间', key: 'created_at', render: fmtTime },
          { title: '操作', key: 'id', render: function (_, r) {
            return '<div class="ops"><a class="layui-btn layui-btn-xs" onclick="App.handleTicket(' + r.id + ')">处理</a></div>';
          } }
        ], d.list);
        pager(document.getElementById('tk-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 崩溃 ----------
  PAGES.crashes = function (el) {
    var page = 1, pageSize = 15;
    function load() {
      api('GET', 'crashes?page=' + page + '&page_size=' + pageSize).then(function (d) {
        el.innerHTML = '<div class="tbl-wrap" id="cr-table"></div><div id="cr-pager"></div>';
        renderTable(document.getElementById('cr-table'), [
          { title: 'ID', key: 'id', width: '50px' },
          { title: '应用', key: 'app_name', render: esc },
          { title: '版本', key: 'version_name', render: function (v, r) { return esc(v) + '<div class="sub">code ' + esc(r.version_code) + '</div>'; } },
          { title: '设备', key: 'device_model', render: function (v) { return esc(v || '-'); } },
          { title: '系统', key: 'os_version', render: function (v) { return esc(v || '-'); } },
          { title: '错误信息', key: 'error_message', render: function (v) { return '<div class="td-ellipsis" title="' + esc(v) + '">' + esc(v) + '</div>'; } },
          { title: '发生时间', key: 'occurred_at', render: fmtTime }
        ], d.list);
        pager(document.getElementById('cr-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 设备 ----------
  PAGES.devices = function (el) {
    var page = 1, pageSize = 15;
    function load() {
      api('GET', 'devices?page=' + page + '&page_size=' + pageSize).then(function (d) {
        el.innerHTML = '<div class="tbl-wrap" id="dev-table"></div><div id="dev-pager"></div>';
        renderTable(document.getElementById('dev-table'), [
          { title: 'ID', key: 'id', width: '50px' },
          { title: '设备号', key: 'device_id', render: esc },
          { title: '型号', key: 'model', render: function (v) { return esc(v || '-'); } },
          { title: '系统版本', key: 'os_version', render: function (v) { return esc(v || '-'); } },
          { title: 'App 版本', key: 'app_version', render: function (v) { return esc(v || '-'); } },
          { title: '渠道', key: 'channel_code', render: function (v) { return esc(v || '-'); } },
          { title: '状态', key: 'status', render: badge },
          { title: '最近活跃', key: 'last_active_at', render: fmtTime }
        ], d.list);
        pager(document.getElementById('dev-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 渠道 ----------
  PAGES.channels = function (el) {
    var page = 1, pageSize = 15;
    function load() {
      api('GET', 'channels?page=' + page + '&page_size=' + pageSize).then(function (d) {
        var html = '<div class="toolbar"><button class="layui-btn layui-btn-sm" onclick="App.openChannelForm()">➕ 新建渠道</button></div>';
        el.innerHTML = html + '<div class="tbl-wrap" id="ch-table"></div><div id="ch-pager"></div>';
        renderTable(document.getElementById('ch-table'), [
          { title: 'ID', key: 'id', width: '50px' },
          { title: '渠道编码', key: 'channel_code', render: esc },
          { title: '渠道名称', key: 'channel_name', render: esc },
          { title: '所属应用', key: 'app_name', render: function (v) { return esc(v || '全局'); } },
          { title: '状态', key: 'status', render: function (v) { return badge(v === 1 ? 'active' : 'disabled'); } },
          { title: '下载量', key: 'download_count', render: function (v) { return v || 0; } },
          { title: '备注', key: 'remark', render: function (v) { return esc(v || '-'); } }
        ], d.list);
        pager(document.getElementById('ch-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 公告 ----------
  PAGES.notices = function (el) {
    function load() {
      api('GET', 'notices').then(function (d) {
        var html = '<div class="toolbar"><button class="layui-btn layui-btn-sm" onclick="App.openNoticeForm()">➕ 新建公告</button></div>';
        el.innerHTML = html + '<div class="tbl-wrap" id="nt-table"></div>';
        renderTable(document.getElementById('nt-table'), [
          { title: 'ID', key: 'id', width: '50px' },
          { title: '标题', key: 'title', render: esc },
          { title: '内容', key: 'content', render: function (v) { return '<div class="td-ellipsis" title="' + esc(v) + '">' + esc(v) + '</div>'; } },
          { title: '应用', key: 'app_name', render: function (v) { return esc(v || '全局'); } },
          { title: '生效期', key: 'start_at', render: function (v, r) { return fmtTime(v) + ' ~ ' + fmtTime(r.end_at); } },
          { title: '状态', key: 'status', render: function (v) { return badge(v === 1 ? 'active' : 'disabled'); } },
          { title: '创建时间', key: 'created_at', render: fmtTime },
          { title: '操作', key: 'id', render: function (_, r) {
            return '<div class="ops"><a class="layui-btn layui-btn-xs" onclick="App.openNoticeForm(' + r.id + ')">编辑</a>'
              + '<a class="layui-btn layui-btn-xs layui-btn-danger" onclick="App.deleteNotice(' + r.id + ')">删除</a></div>';
          } }
        ], d.list);
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 数据统计 ----------
  PAGES.stats = function (el) {
    Promise.all([
      api('GET', 'downloads?days=7'),
      api('GET', 'updates?days=7'),
      api('GET', 'stats/versions'),
      api('GET', 'stats/platforms'),
      api('GET', 'stats/channels'),
      api('GET', 'stats/feedbacks')
    ]).then(function (r) {
      var dl = r[0], up = r[1], vStat = r[2], pf = r[3], ch = r[4], fb = r[5];
      var html = '<div class="stat-grid" style="grid-template-columns:repeat(4,1fr)">'
        + '<div class="stat-card"><div class="stat-icon">⬇️</div><div class="stat-value">' + dl.total + '</div><div class="stat-label">近 7 日下载</div></div>'
        + '<div class="stat-card"><div class="stat-icon">🔄</div><div class="stat-value">' + up.total + '</div><div class="stat-label">近 7 日升级检测</div></div>'
        + '<div class="stat-card"><div class="stat-icon">📟</div><div class="stat-value">' + vStat.total_devices + '</div><div class="stat-label">在线设备</div></div>'
        + '<div class="stat-card"><div class="stat-icon">📦</div><div class="stat-value">' + (pf.total || 0) + '</div><div class="stat-label">安装包文件</div></div></div>';

      var panel = function (title, items, nameFn, valFn) {
        var max = Math.max.apply(null, items.map(function (x) { return valFn(x); }).concat([1]));
        var h = '<div class="layui-card"><div class="layui-card-header">' + title + '</div><div class="layui-card-body"><div class="hbar">';
        items.forEach(function (x) {
          h += '<div class="hbar-row"><span class="hbar-name">' + esc(nameFn(x)) + '</span><div class="hbar-track"><div class="hbar-fill" style="width:' + Math.round(valFn(x) / max * 100) + '%"></div></div><span class="hbar-val">' + valFn(x) + '</span></div>';
        });
        h += '</div></div></div>';
        return h;
      };
      html += '<div class="chart-panels">';
      html += panel('7 日下载趋势', dl.by_day || [], function (x) { return x.date; }, function (x) { return x.downloads; });
      html += panel('7 日升级趋势', up.by_day || [], function (x) { return x.date; }, function (x) { return x.updates; });
      html += panel('下载 Top 应用', dl.by_app || [], function (x) { return x.app_name; }, function (x) { return x.downloads; });
      html += panel('升级版本分布', up.by_version || [], function (x) { return x.version; }, function (x) { return x.checks; });
      html += panel('版本占用', vStat.list || [], function (x) { return x.version; }, function (x) { return x.count; });
      html += panel('平台分布', pf.list || [], function (x) { return x.platform; }, function (x) { return x.count; });
      html += panel('渠道分布', ch.list || [], function (x) { return x.channel || '未知'; }, function (x) { return x.count; });
      html += panel('反馈类型', fb.by_type || [], function (x) { return x.type; }, function (x) { return x.total; });
      html += '</div>';
      el.innerHTML = html;
    }).catch(errMsg);
  };

  // ---------- 下载中心（二维码） ----------
  PAGES['download-center'] = function (el) {
    api('GET', 'apps?page=1&page_size=100').then(function (d) {
      var html = '<div class="layui-row">' + (d.list || []).map(function (a) {
        return '<div class="layui-col-md4"><div class="layui-card"><div class="layui-card-header">' + esc(a.name) + ' <span class="sub">' + esc(a.code) + '</span></div>'
          + '<div class="layui-card-body dc-body">'
          + '<div class="dc-steps"><div>官方页：<code>' + esc('/app/' + a.code) + '</code></div>'
          + '<div>最新版下载：<code>' + esc('/download/' + a.code) + '</code></div>'
          + '<div>渠道下载：<code>' + esc('/download/' + a.code + '?channel=agent_a') + '</code></div></div>'
          + '<div class="dc-qr-grid">'
          + '<div class="dc-qr"><div class="dc-qr-title">官方</div><div class="qr-render" data-url="/app/' + esc(a.code) + '"></div></div>'
          + '<div class="dc-qr"><div class="dc-qr-title">最新版</div><div class="qr-render" data-url="/download/' + esc(a.code) + '"></div></div>'
          + '<div class="dc-qr"><div class="dc-qr-title">渠道版</div><div class="qr-render" data-url="/download/' + esc(a.code) + '?channel=agent_a"></div></div>'
          + '</div></div></div></div>';
      }).join('') + '</div>';
      el.innerHTML = html || '<div class="tbl-empty">暂无应用，请先创建</div>';
      el.querySelectorAll('.qr-render').forEach(function (box) {
        try {
          new QRCode(box, { text: location.origin + box.dataset.url, width: 110, height: 110, colorDark: '#1a1a2e', colorLight: '#ffffff', correctLevel: QRCode.CorrectLevel.M });
        } catch (e) { box.textContent = '生成失败'; }
      });
    }).catch(errMsg);
  };

  // ---------- 管理员 ----------
  PAGES.admins = function (el) {
    api('GET', 'admins').then(function (d) {
      var rows = (d.list || []).map(function (a) {
        return {
          id: a.id, username: a.username, nickname: a.nickname, email: a.email || '-',
          roles: (a.roles || []).map(function (r) { return r.name; }).join('，') || '-',
          status: a.status, last_login_at: a.last_login_at, last_login_ip: a.last_login_ip || '-'
        };
      });
      el.innerHTML = '<div class="tbl-wrap" id="am-table"></div>';
      renderTable(document.getElementById('am-table'), [
        { title: 'ID', key: 'id', width: '50px' },
        { title: '用户名', key: 'username', render: esc },
        { title: '昵称', key: 'nickname', render: esc },
        { title: '邮箱', key: 'email', render: esc },
        { title: '角色', key: 'roles', render: esc },
        { title: '状态', key: 'status', render: function (v) { return badge(v === 1 ? 'active' : 'disabled'); } },
        { title: '最近登录', key: 'last_login_at', render: fmtTime },
        { title: '登录 IP', key: 'last_login_ip', render: esc }
      ], rows);
    }).catch(errMsg);
  };

  // ---------- 角色与权限 ----------
  PAGES.roles = function (el) {
    Promise.all([api('GET', 'roles'), api('GET', 'permissions')]).then(function (r) {
      var roles = r[0], perms = r[1];
      var html = '<div class="tbl-wrap" id="role-table"></div><div class="layui-card"><div class="layui-card-header">权限树</div><div class="layui-card-body"><div class="perm-tree">';
      html += perms.map(function (p) {
        var kids = '';
        (p.children || []).forEach(function (c) {
          kids += '<span class="perm-node">' + esc(c.name) + ' <code>' + esc(c.code) + '</code></span>';
        });
        return '<div class="perm-group"><span class="perm-root">' + esc(p.name) + ' <code>' + esc(p.code) + '</code></span>' + (kids ? '<div class="perm-children">' + kids + '</div>' : '') + '</div>';
      }).join('');
      html += '</div></div></div>';
      el.innerHTML = html;
      renderTable(document.getElementById('role-table'), [
        { title: 'ID', key: 'id', width: '50px' },
        { title: '角色', key: 'name', render: esc },
        { title: '编码', key: 'code', render: function (v) { return '<code>' + esc(v) + '</code>'; } },
        { title: '权限数', key: 'permission_count', width: '90px' },
        { title: '管理员数', key: 'admin_count', width: '90px' },
        { title: '状态', key: 'status', render: function (v) { return badge(v === 1 ? 'active' : 'disabled'); } },
        { title: '操作', key: 'id', render: function (_, r) {
          return '<div class="ops"><a class="layui-btn layui-btn-xs" onclick="App.openRoleForm(' + r.id + ')">配置权限</a></div>';
        } }
      ], roles);
    }).catch(errMsg);
  };

  // ---------- 操作日志 ----------
  PAGES.logs = function (el) {
    var page = 1, pageSize = 20;
    function load() {
      api('GET', 'operation-logs?page=' + page + '&page_size=' + pageSize).then(function (d) {
        el.innerHTML = '<div class="tbl-wrap" id="lg-table"></div><div id="lg-pager"></div>';
        renderTable(document.getElementById('lg-table'), [
          { title: 'ID', key: 'id', width: '60px' },
          { title: '操作人', key: 'admin_name', render: esc },
          { title: '模块', key: 'module', render: esc },
          { title: '动作', key: 'action', render: esc },
          { title: '描述', key: 'description', render: esc },
          { title: 'IP', key: 'ip', render: esc },
          { title: '时间', key: 'created_at', render: fmtTime }
        ], d.list);
        pager(document.getElementById('lg-pager'), d.total, page, pageSize, function (p) { page = p; load(); });
      }).catch(errMsg);
    }
    load();
  };

  // ---------- 路由 ----------
  function route() {
    var hash = location.hash.replace(/^#\//, '') || 'dashboard';
    var parts = hash.split('?');
    var name = parts[0];
    var query = {};
    (parts[1] || '').split('&').forEach(function (kv) {
      var i = kv.indexOf('=');
      if (i > 0) query[kv.slice(0, i)] = decodeURIComponent(kv.slice(i + 1));
    });
    state.page = name;
    var body = document.getElementById('app-body');
    if (PAGES[name]) { PAGES[name](body, query); }
    else { body.innerHTML = '<div class="tbl-empty">页面不存在</div>'; }
    // 高亮菜单
    document.querySelectorAll('#side-menu [data-page]').forEach(function (li) {
      li.classList.remove('layui-this');
      if (li.getAttribute('data-page') === name) li.classList.add('layui-this');
    });
  }

  // ---------- 对外接口 ----------
  window.App = {
    init: function () {
      try {
        var t = localStorage.getItem(TOKEN_KEY);
        var a = localStorage.getItem(ADMIN_KEY);
        if (t) { state.token = t; state.admin = a ? JSON.parse(a) : null; }
      } catch (e) {}
      this.refreshUser();
      this.checkAuth();
      window.addEventListener('hashchange', route);
      route();
    },

    checkAuth: function () {
      var shell = document.getElementById('login-shell');
      var layout = document.querySelector('.layui-layout-admin');
      if (!state.token) {
        shell.style.display = 'flex';
        layout.style.display = 'none';
        document.getElementById('app-body').innerHTML = '';
      } else {
        shell.style.display = 'none';
        layout.style.display = '';
        route();
      }
    },

    refreshUser: function () {
      var el = document.getElementById('user-info');
      if (el && state.admin) el.textContent = '👤 ' + (state.admin.nickname || state.admin.username || '管理员');
    },

    doLogin: function (ev) {
      if (ev) ev.preventDefault();
      var username = document.getElementById('login-username').value.trim();
      var password = document.getElementById('login-password').value;
      var msg = document.getElementById('login-msg');
      msg.textContent = '';
      if (!username || !password) { msg.textContent = '请输入用户名和密码'; return false; }
      fetch('/api/v1/admin/login', {
        method: 'POST', headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username: username, password: password })
      }).then(function (r) { return r.json(); }).then(function (json) {
        if (json.code !== 0) { msg.textContent = json.message || '登录失败'; return; }
        state.token = json.data.token;
        state.admin = json.data.admin;
        try {
          localStorage.setItem(TOKEN_KEY, state.token);
          localStorage.setItem(ADMIN_KEY, JSON.stringify(state.admin));
        } catch (e) {}
        this.refreshUser();
        this.checkAuth();
      }.bind(this)).catch(function () { msg.textContent = '网络错误，请重试'; });
      return false;
    },

    logout: function (silent) {
      if (state.token && !silent) {
        try { fetch('/api/v1/admin/logout', { method: 'POST', headers: { 'Authorization': 'Bearer ' + state.token } }); } catch (e) {}
      }
      state.token = ''; state.admin = null;
      try { localStorage.removeItem(TOKEN_KEY); localStorage.removeItem(ADMIN_KEY); } catch (e) {}
      location.hash = '';
      this.checkAuth();
    },

    // ---- 应用 ----
    openAppForm: function (id) { AppForm.app(id); },
    toggleApp: function (id, to) {
      layer.confirm(to === 1 ? '确定启用该应用？' : '停用后前台将无法访问，确定停用？', function (idx) {
        layer.close(idx);
        api('POST', 'apps/' + id + '/' + (to === 1 ? 'enable' : 'disable')).then(function () {
          toast(); route();
        }).catch(errMsg);
      });
    },

    // ---- 版本 ----
    openUploadForm: function () { AppForm.upload(); },
    openVersionForm: function (id) { AppForm.version(id); },
    deleteVersion: function (id) {
      layer.confirm('确定删除该版本？该操作不可恢复。', function (idx) {
        layer.close(idx);
        api('DELETE', 'versions/' + id).then(function () { toast(); route(); }).catch(errMsg);
      });
    },
    publishVersion: function (id) { AppForm.publish(id); },
    pauseVersion: function (id) {
      layer.confirm('确定暂停该版本的发布？设备将不再收到更新推送。', function (idx) {
        layer.close(idx);
        api('POST', 'versions/' + id + '/pause').then(function () { toast(); route(); }).catch(errMsg);
      });
    },
    rollbackVersion: function (id) {
      layer.confirm('确定回滚该版本？系统将恢复上一可用版本并通知设备升级。', function (idx) {
        layer.close(idx);
        api('POST', 'versions/' + id + '/rollback').then(function () { toast(); route(); }).catch(errMsg);
      });
    },

    // ---- 反馈 / 工单 ----
    viewFeedback: function (id) {
      api('GET', 'feedbacks/' + id).then(function (f) {
        var imgHtml = '';
        if (f.images) {
          try {
            var imgs = typeof f.images === 'string' ? JSON.parse(f.images || '[]') : (f.images || []);
            imgHtml = '<div class="fb-imgs">' + imgs.map(function (u) { return '<img src="' + esc(u) + '" loading="lazy">'; }).join('') + '</div>';
          } catch (e) {}
        }
        openPanel({
          type: 1, title: '反馈详情 #' + f.id, area: ['560px', 'auto'], content:
            '<div class="panel-form">' +
            '<p><label>应用：</label>' + esc(f.app_name) + '</p>' +
            '<p><label>标题：</label>' + esc(f.title) + '</p>' +
            '<p><label>类型：</label>' + esc(f.type) + '</p>' +
            '<p><label>版本：</label>' + esc(f.app_version || '-') + ' / ' + esc(f.os_version || '-') + '</p>' +
            '<p><label>设备：</label>' + esc(f.device_model || '-') + ' / ' + esc(f.device_id || '-') + '</p>' +
            '<p><label>渠道：</label>' + esc(f.channel_code || '-') + '</p>' +
            '<div><label>内容：</label><div class="fb-content">' + esc(f.content) + '</div></div>' +
            imgHtml +
            (f.contact ? '<p><label>联系方式：</label>' + esc(f.contact) + '</p>' : '') +
            (f.ticket ? '<p><label>关联工单：</label><a class="layui-btn layui-btn-xs layui-btn-normal" href="#/tickets?kw=' + encodeURIComponent(f.ticket.ticket_no) + '">' + esc(f.ticket.ticket_no) + '</a></p>' : '') +
            '<p><label>状态：</label>' + badge(f.status) + '</p>' +
            '<p><label>时间：</label>' + fmtTime(f.created_at) + '</p>' +
            '</div>'
        });
      }).catch(errMsg);
    },
    handleTicket: function (id) { AppForm.ticket(id); },

    // ---- 渠道 ----
    openChannelForm: function () { AppForm.channel(); },

    // ---- 公告 ----
    openNoticeForm: function (id) { AppForm.notice(id); },
    deleteNotice: function (id) {
      layer.confirm('确定删除该公告？', function (idx) {
        layer.close(idx);
        api('DELETE', 'notices/' + id).then(function () { toast(); route(); }).catch(errMsg);
      });
    },

    // ---- 角色 ----
    openRoleForm: function (id) { AppForm.role(id); },

    publishImmediate: function (vid) { App.publishVersion(vid); }
  };

  // ==================== 弹窗表单 ====================
  var AppForm = {
    app: function (id) {
      if (!id) {
        this._app(0, { name: '', code: '', package_name: '', bundle_id: '', description: '', website: '', contact: '', sort_order: 0 });
        return;
      }
      var self = this;
      api('GET', 'apps/' + id).then(function (d) { self._app(id, d); }).catch(errMsg);
    },
    _app: function (id, d) {
      openPanel({
        type: 1, title: id ? '编辑应用' : '新建应用', area: ['620px', 'auto'],
        content:
          '<form class="layui-form panel-form" onsubmit="return AppForm.saveApp(event, ' + (id || 0) + ')">' +
          '<div class="layui-form-item"><label class="layui-form-label">名称 *</label><div class="layui-input-block"><input class="layui-input" name="name" value="' + esc(d.name) + '" required></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">App Code *</label><div class="layui-input-block"><input class="layui-input" name="code" value="' + esc(d.code) + '" ' + (id ? 'disabled' : 'required pattern="[a-zA-Z][a-zA-Z0-9_-]{1,63}"') + '></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">包名</label><div class="layui-input-block"><input class="layui-input" name="package_name" value="' + esc(d.package_name || '') + '"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">Bundle ID</label><div class="layui-input-block"><input class="layui-input" name="bundle_id" value="' + esc(d.bundle_id || '') + '"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">图标 URL</label><div class="layui-input-block"><input class="layui-input" name="icon" value="' + esc(d.icon || '') + '"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">简介</label><div class="layui-input-block"><textarea class="layui-textarea" name="description">' + esc(d.description || '') + '</textarea></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">官网</label><div class="layui-input-block"><input class="layui-input" name="website" value="' + esc(d.website || '') + '"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">联系方式</label><div class="layui-input-block"><input class="layui-input" name="contact" value="' + esc(d.contact || '') + '"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">排序</label><div class="layui-input-block"><input class="layui-input" type="number" name="sort_order" value="' + esc(d.sort_order || 0) + '"></div></div>' +
          '<div class="layui-form-item"><div class="layui-input-block"><button class="layui-btn" type="submit">保存</button></div></div>' +
          '</form>'
      });
    },
    saveApp: function (ev, id) {
      ev.preventDefault();
      var form = ev.target, data = {};
      new FormData(form).forEach(function (v, k) { data[k] = v; });
      if (!data.name || (!id && !data.code)) { layer.msg('名称和 App Code 必填'); return false; }
      var req = id ? api('PUT', 'apps/' + id, data) : api('POST', 'apps', data);
      req.then(function () { layer.closeAll(); toast(); route(); }).catch(errMsg);
      return false;
    },

    upload: function () {
      var self = this;
      api('GET', 'apps?page=1&page_size=100').then(function (d) {
        var apps = d.list || [];
        if (!apps.length) { layer.msg('请先创建应用'); return; }
        var html =
          '<form class="layui-form panel-form" onsubmit="return AppForm.saveUpload(event)">' +
          '<div class="layui-form-item"><label class="layui-form-label">应用 *</label><div class="layui-input-block"><select name="app_id" class="layui-input">' +
          apps.map(function (a) { return '<option value="' + a.id + '">' + esc(a.name) + ' (' + esc(a.code) + ')</option>'; }).join('') +
          '</select></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">版本名 *</label><div class="layui-input-block"><input class="layui-input" name="version_name" placeholder="如 1.0.0" required></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">Version Code *</label><div class="layui-input-block"><input class="layui-input" type="number" name="version_code" placeholder="整数，如 100" required></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">平台 *</label><div class="layui-input-block"><select name="platform" class="layui-input">' +
          '<option value="android">Android (.apk/.aab)</option><option value="ios">iOS (.ipa)</option><option value="windows">Windows (.exe/.zip)</option><option value="macos">macOS (.dmg/.zip)</option><option value="linux">Linux (.deb/.AppImage/.zip)</option><option value="other">其他</option>' +
          '</select></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">架构</label><div class="layui-input-block"><input class="layui-input" name="architecture" placeholder="如 arm64-v8a / x86_64，留空不限制"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">安装包 *</label><div class="layui-input-block"><input type="file" name="package_file" required></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">更新标题</label><div class="layui-input-block"><input class="layui-input" name="release_title" placeholder="如：新版本发布"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">更新说明</label><div class="layui-input-block"><textarea class="layui-textarea" name="release_note" placeholder="本次更新的主要内容…"></textarea></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">强制升级</label><div class="layui-input-block"><input type="checkbox" name="is_force_update" value="1" lay-skin="switch"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">最低版本码</label><div class="layui-input-block"><input class="layui-input" type="number" name="minimum_version_code" placeholder="低于该 code 强制升级（可留空）"></div></div>' +
          '<div class="layui-form-item"><div class="layui-input-block"><button class="layui-btn" type="submit">上传并创建版本</button></div></div>' +
          '</form>';
        openPanel({ type: 1, title: '上传安装包', area: ['640px', 'auto'], content: html });
      }).catch(errMsg);
    },
    saveUpload: function (ev) {
      ev.preventDefault();
      var form = ev.target;
      var fd = new FormData(form);
      if (!fd.get('package_file').size) { layer.msg('请选择安装包文件'); return false; }
      var appId = fd.get('app_id');
      api('POST', 'apps/' + appId + '/upload', fd, true).then(function () {
        layer.closeAll(); toast('上传成功'); route();
      }).catch(errMsg);
      return false;
    },

    version: function (id) {
      var self = this;
      api('GET', 'versions/' + id).then(function (d) { self._version(id, d); }).catch(errMsg);
    },
    _version: function (id, v) {
      openPanel({
        type: 1, title: '编辑版本 #' + id, area: ['620px', 'auto'],
        content:
          '<form class="layui-form panel-form" onsubmit="return AppForm.saveVersion(event)">' +
          '<input type="hidden" name="version_id" value="' + id + '">' +
          '<div class="layui-form-item"><label class="layui-form-label">更新标题</label><div class="layui-input-block"><input class="layui-input" name="release_title" value="' + esc(v.release_title || '') + '"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">更新说明</label><div class="layui-input-block"><textarea class="layui-textarea" name="release_note">' + esc(v.release_note || '') + '</textarea></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">系统要求</label><div class="layui-input-block"><input class="layui-input" name="os_version" value="' + esc(v.os_version || '') + '"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">架构</label><div class="layui-input-block"><input class="layui-input" name="architecture" value="' + esc(v.architecture || '') + '"></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">强制升级</label><div class="layui-input-block"><input type="checkbox" name="is_force_update" value="1" lay-skin="switch" ' + (v.is_force_update === 1 ? 'checked' : '') + '></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">最低版本码</label><div class="layui-input-block"><input class="layui-input" type="number" name="minimum_version_code" value="' + esc(v.minimum_version_code || '') + '"></div></div>' +
          '<div class="layui-form-item"><div class="layui-input-block"><button class="layui-btn" type="submit">保存</button></div></div>' +
          '</form>'
      });
    },
    saveVersion: function (ev) {
      ev.preventDefault();
      var form = ev.target, data = {};
      new FormData(form).forEach(function (v, k) { if (k !== 'version_id') data[k] = v; });
      data.is_force_update = data.is_force_update === '1' ? 1 : 0;
      api('PUT', 'versions/' + form.version_id.value, data).then(function () {
        layer.closeAll(); toast(); route();
      }).catch(errMsg);
      return false;
    },

    publish: function (id) {
      api('GET', 'versions/' + id).then(function (v) {
        openPanel({
          type: 1, title: '发布版本 ' + v.version_name, area: ['520px', 'auto'],
          content:
            '<form class="layui-form panel-form" onsubmit="return AppForm.savePublish(event)">' +
            '<input type="hidden" name="version_id" value="' + id + '">' +
            '<div class="layui-form-item"><label class="layui-form-label">发布名称</label><div class="layui-input-block"><input class="layui-input" name="name" value="发布 ' + esc(v.version_name) + '"></div></div>' +
            '<div class="layui-form-item"><label class="layui-form-label">发布类型 *</label><div class="layui-input-block"><select name="release_type" onchange="this.form.rollout_area.style.display = this.value === \'gray\' ? \'\' : \'none\'">' +
            '<option value="full">全量发布</option><option value="gray" ' + (v.last_release === 1 ? '' : '') + '>灰度发布</option>' +
            '</select></div></div>' +
            '<div class="layui-form-item" name="rollout_area" style="display:none"><label class="layui-form-label">灰度比例 %</label><div class="layui-input-block"><input class="layui-input" type="number" min="1" max="100" name="rollout_percent" value="10"></div></div>' +
            '<div class="layui-form-item"><label class="layui-form-label">渠道规则</label><div class="layui-input-block"><input class="layui-input" name="rules" placeholder="JSON 数组，如 [{\"field\":\"channel_code\",\"op\":\"=\",\"value\":\"agent_a\"}]，留空不限制"></div></div>' +
            '<div class="layui-form-item"><div class="layui-input-block"><button class="layui-btn" type="submit">确认发布</button></div></div>' +
            '</form>'
        });
      }).catch(errMsg);
    },
    savePublish: function (ev) {
      ev.preventDefault();
      var form = ev.target, data = {};
      new FormData(form).forEach(function (v, k) { if (k !== 'version_id') data[k] = v; });
      var rulesRaw = String(data.rules || '').trim();
      data.rules = rulesRaw;
      api('POST', 'versions/' + form.version_id.value + '/publish', data).then(function () {
        layer.closeAll(); toast('发布成功'); route();
      }).catch(errMsg);
      return false;
    },

    ticket: function (id) {
      var self = this;
      Promise.all([api('GET', 'tickets/' + id), api('GET', 'admins'), api('GET', 'versions?page=1&page_size=100')]).then(function (r) {
        var t = r[0], admins = r[1].list || [], versions = r[2].list || [];
        var html =
          '<form class="layui-form panel-form" onsubmit="return AppForm.saveTicket(event)">' +
          '<input type="hidden" name="ticket_id" value="' + id + '">' +
          '<div class="layui-form-item"><label class="layui-form-label">单号</label><div class="layui-input-block"><input class="layui-input" value="' + esc(t.ticket_no) + '" disabled></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">标题</label><div class="layui-input-block"><input class="layui-input" value="' + esc(t.title) + '" disabled></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">内容</label><div class="layui-input-block"><textarea class="layui-textarea" disabled>' + esc(t.content || '') + '</textarea></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">状态</label><div class="layui-input-block"><select name="status" class="layui-input">' +
          '<option value="open" ' + (t.status === 'open' ? 'selected' : '') + '>待处理</option>' +
          '<option value="processing" ' + (t.status === 'processing' ? 'selected' : '') + '>处理中</option>' +
          '<option value="solved" ' + (t.status === 'solved' ? 'selected' : '') + '>已解决</option>' +
          '<option value="closed" ' + (t.status === 'closed' ? 'selected' : '') + '>已关闭</option>' +
          '</select></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">指派给</label><div class="layui-input-block"><select name="assignee_id" class="layui-input"><option value="">不指派</option>' +
          admins.map(function (a) { return '<option value="' + a.id + '" ' + (t.assignee_id === a.id ? 'selected' : '') + '>' + esc(a.nickname || a.username) + '</option>'; }).join('') +
          '</select></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">修复版本</label><div class="layui-input-block"><select name="fixed_version_id" class="layui-input"><option value="">未指定</option>' +
          versions.filter(function (v) { return v.status === 'published'; }).map(function (v) {
            return '<option value="' + v.id + '" ' + (t.fixed_version_id === v.id ? 'selected' : '') + '>' + esc(v.app_name) + ' ' + esc(v.version_name) + '</option>';
          }).join('') +
          '</select></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">解决方案</label><div class="layui-input-block"><textarea class="layui-textarea" name="solution">' + esc(t.solution || '') + '</textarea></div></div>' +
          '<div class="layui-form-item"><div class="layui-input-block"><button class="layui-btn" type="submit">保存处理</button></div></div>' +
          '</form>';
        openPanel({ type: 1, title: '处理工单 ' + t.ticket_no, area: ['620px', 'auto'], content: html });
      }).catch(function (e) {
        // 没有版本数据时降级渲染
        if (e && e.fallbacks) { /* noop */ }
        errMsg(e);
      });
    },
    saveTicket: function (ev) {
      ev.preventDefault();
      var form = ev.target, data = {};
      new FormData(form).forEach(function (v, k) { if (k !== 'ticket_id') data[k] = v; });
      data.fixed_version_id = data.fixed_version_id ? parseInt(data.fixed_version_id, 10) : null;
      data.assignee_id = data.assignee_id ? parseInt(data.assignee_id, 10) : null;
      api('PUT', 'tickets/' + form.ticket_id.value, data).then(function () {
        layer.closeAll(); toast(); route();
      }).catch(errMsg);
      return false;
    },

    channel: function () {
      api('GET', 'apps?page=1&page_size=100').then(function (d) {
        openPanel({
          type: 1, title: '新建渠道', area: ['520px', 'auto'],
          content:
            '<form class="layui-form panel-form" onsubmit="return AppForm.saveChannel(event)">' +
            '<div class="layui-form-item"><label class="layui-form-label">渠道编码 *</label><div class="layui-input-block"><input class="layui-input" name="channel_code" placeholder="如 agent_a" required></div></div>' +
            '<div class="layui-form-item"><label class="layui-form-label">渠道名称 *</label><div class="layui-input-block"><input class="layui-input" name="channel_name" required></div></div>' +
            '<div class="layui-form-item"><label class="layui-form-label">所属应用</label><div class="layui-input-block"><select name="app_id" class="layui-input"><option value="">全局渠道</option>' +
            (d.list || []).map(function (a) { return '<option value="' + a.id + '">' + esc(a.name) + '</option>'; }).join('') +
            '</select></div></div>' +
            '<div class="layui-form-item"><label class="layui-form-label">备注</label><div class="layui-input-block"><input class="layui-input" name="remark"></div></div>' +
            '<div class="layui-form-item"><div class="layui-input-block"><button class="layui-btn" type="submit">创建</button></div></div>' +
            '</form>'
        });
      }).catch(errMsg);
    },
    saveChannel: function (ev) {
      ev.preventDefault();
      var form = ev.target, data = {};
      new FormData(form).forEach(function (v, k) { data[k] = v; });
      data.status = 1;
      api('POST', 'channels', data).then(function () {
        layer.closeAll(); toast(); route();
      }).catch(errMsg);
      return false;
    },

    notice: function (id) {
      var self = this;
      var open = function (d) {
        api('GET', 'apps?page=1&page_size=100').then(function (ad) {
          openPanel({
            type: 1, title: id ? '编辑公告' : '新建公告', area: ['580px', 'auto'],
            content:
              '<form class="layui-form panel-form" onsubmit="return AppForm.saveNotice(event)">' +
              '<input type="hidden" name="notice_id" value="' + (id || 0) + '">' +
              '<div class="layui-form-item"><label class="layui-form-label">标题 *</label><div class="layui-input-block"><input class="layui-input" name="title" value="' + esc(d.title || '') + '" required></div></div>' +
              '<div class="layui-form-item"><label class="layui-form-label">内容 *</label><div class="layui-input-block"><textarea class="layui-textarea" name="content" required>' + esc(d.content || '') + '</textarea></div></div>' +
              '<div class="layui-form-item"><label class="layui-form-label">所属应用</label><div class="layui-input-block"><select name="app_id" class="layui-input"><option value="">全局公告</option>' +
              (ad.list || []).map(function (a) { return '<option value="' + a.id + '" ' + (d.app_id === a.id ? 'selected' : '') + '>' + esc(a.name) + '</option>'; }).join('') +
              '</select></div></div>' +
              '<div class="layui-form-item"><label class="layui-form-label">生效时间</label><div class="layui-input-block"><input class="layui-input" name="start_at" placeholder="YYYY-MM-DD HH:MM:SS，留空立即生效" value="' + esc(d.start_at || '') + '"></div></div>' +
              '<div class="layui-form-item"><label class="layui-form-label">结束时间</label><div class="layui-input-block"><input class="layui-input" name="end_at" placeholder="YYYY-MM-DD HH:MM:SS，留空不结束" value="' + esc(d.end_at || '') + '"></div></div>' +
              '<div class="layui-form-item"><label class="layui-form-label">状态</label><div class="layui-input-block"><input type="checkbox" name="status" value="1" lay-skin="switch" ' + (d.status === 1 ? 'checked' : '') + '></div></div>' +
              '<div class="layui-form-item"><div class="layui-input-block"><button class="layui-btn" type="submit">保存</button></div></div>' +
              '</form>'
          });
        }).catch(errMsg);
      };
      if (id) { api('GET', 'notices/' + id).then(open).catch(errMsg); }
      else { open({}); }
    },
    saveNotice: function (ev) {
      ev.preventDefault();
      var form = ev.target, data = {};
      new FormData(form).forEach(function (v, k) { if (k !== 'notice_id') data[k] = v; });
      data.status = data.status === '1' ? 1 : 0;
      data.app_id = data.app_id ? parseInt(data.app_id, 10) : null;
      var id = parseInt(form.notice_id.value, 10);
      var req = id ? api('PUT', 'notices/' + id, data) : api('POST', 'notices', data);
      req.then(function () { layer.closeAll(); toast(); route(); }).catch(errMsg);
      return false;
    },

    role: function (id) {
      var self = this;
      Promise.all([api('GET', 'roles'), api('GET', 'permissions')]).then(function (r) {
        var role = (r[0] || []).filter(function (x) { return x.id === id; })[0];
        if (!role) { layer.msg('角色不存在'); return; }
        var perms = r[1] || [];
        var flat = [];
        perms.forEach(function (p) { flat.push(p); (p.children || []).forEach(function (c) { flat.push(c); }); });
        var checked = {};
        if (role.permissions) {
          try {
            (typeof role.permissions === 'string' ? JSON.parse(role.permissions) : role.permissions).forEach(function (p) {
              checked[typeof p === 'object' && p !== null ? p.id : p] = true;
            });
          } catch (e) {}
        }
        var html =
          '<form class="layui-form panel-form" onsubmit="return AppForm.saveRole(event)">' +
          '<input type="hidden" name="role_id" value="' + id + '">' +
          '<div class="layui-form-item"><label class="layui-form-label">角色</label><div class="layui-input-block"><input class="layui-input" value="' + esc(role.name) + '" disabled></div></div>' +
          '<div class="layui-form-item"><label class="layui-form-label">权限</label><div class="layui-input-block perm-check-list">' +
          flat.map(function (p) {
            return '<label class="perm-check"><input type="checkbox" name="permission_ids" value="' + p.id + '" ' + (checked[p.id] ? 'checked' : '') + ' lay-skin="primary"> <span>' + esc(p.name) + '</span> <code>' + esc(p.parent_id ? '' : '') + esc(p.code) + '</code></label>';
          }).join('') +
          '</div></div>' +
          '<div class="layui-form-item"><div class="layui-input-block"><button class="layui-btn" type="submit">保存权限</button></div></div>' +
          '</form>';
        openPanel({ type: 1, title: '配置角色权限：' + role.name, area: ['640px', 'auto'], content: html });
      }).catch(errMsg);
    },
    saveRole: function (ev) {
      ev.preventDefault();
      var form = ev.target;
      var ids = Array.prototype.filter.call(form.querySelectorAll('input[name="permission_ids"]:checked'), function (i) { return i.checked; }).map(function (i) { return parseInt(i.value, 10); });
      api('PUT', 'roles/' + form.role_id.value, { permissions: ids }).then(function () {
        layer.closeAll(); toast(); route();
      }).catch(errMsg);
      return false;
    }
  };
  window.AppForm = AppForm;

  // bootstrap：等待 DOM 与 layui.layer 就绪后启动
  function boot() {
    function start() { App.init(); }
    if (document.readyState === 'loading') {
      document.addEventListener('DOMContentLoaded', boot);
      return;
    }
    if (window.layui && window.layui.use) {
      window.layui.use(['layer'], function () {
        if (!window.layer) window.layer = window.layui.layer;
        start();
      });
    } else {
      start();
    }
  }
  boot();
})();