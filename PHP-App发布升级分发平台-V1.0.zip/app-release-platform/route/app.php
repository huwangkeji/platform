<?php
// +----------------------------------------------------------------------
// | PHP App发布/升级分发平台 V1.0 路由定义
// +----------------------------------------------------------------------
use think\facade\Route;

use app\middleware\AuthAdmin;
use app\middleware\AuthUser;
use app\middleware\RbacCheck;

// 健康检查
Route::get('ping', function () {
    return json(['code' => 0, 'message' => 'pong', 'data' => date('Y-m-d H:i:s')]);
});

// ---------------- 前台页面 ----------------
Route::get('/', 'Index/index')->completeMatch();
Route::get('app/:code', 'Index/download');
Route::get('app/:code/history', 'Index/history');
Route::get('download/:id', 'Index/downloadRedirect')->pattern(['id' => '\d+']);
Route::get('download/version/:id', 'Index/downloadRedirect')->pattern(['id' => '\d+']);
// 渠道二维码下载：/download/{app_code}?channel=agent_a → 最新可用版本
Route::get('download/:code', 'Index/downloadByCode');
Route::get('admin', 'Index/admin')->completeMatch();
Route::get('admin/:page', 'Index/admin');

// ---------------- API v1 ----------------
Route::group('api/v1', function () {

    // 管理员登录（公开）
    Route::post('admin/login', 'api.Admin/login')->completeMatch();

    // 管理端接口（需登录 + 权限）
    Route::group('admin', function () {
        // 认证
        Route::post('logout', 'api.Admin/logout')->completeMatch();

        // Dashboard
        Route::get('dashboard', 'admin.Dashboard/index')->completeMatch();
        Route::get('dashboard/trend', 'admin.Dashboard/trend')->middleware(RbacCheck::class, 'stat.view')->completeMatch();
        Route::get('dashboard/charts', 'admin.Dashboard/charts')->middleware(RbacCheck::class, 'stat.view')->completeMatch();

        // 应用管理
        Route::get('apps', 'admin.Apps/index')->middleware(RbacCheck::class, 'app.view')->completeMatch();
        Route::post('apps', 'admin.Apps/create')->middleware(RbacCheck::class, 'app.edit')->completeMatch();
        Route::get('apps/:id', 'admin.Apps/read')->middleware(RbacCheck::class, 'app.view')->pattern(['id' => '\d+']);
        Route::put('apps/:id', 'admin.Apps/update')->middleware(RbacCheck::class, 'app.edit')->pattern(['id' => '\d+']);
        Route::delete('apps/:id', 'admin.Apps/delete')->middleware(RbacCheck::class, 'app.edit')->pattern(['id' => '\d+']);
        Route::post('apps/:id/enable', 'admin.Apps/enable')->middleware(RbacCheck::class, 'app.edit')->pattern(['id' => '\d+']);
        Route::post('apps/:id/disable', 'admin.Apps/disable')->middleware(RbacCheck::class, 'app.edit')->pattern(['id' => '\d+']);
        Route::get('apps/:id/versions', 'admin.Versions/index')->middleware(RbacCheck::class, 'version.view')->pattern(['id' => '\d+']);

        // 版本管理
        Route::get('versions', 'admin.Versions/index')->middleware(RbacCheck::class, 'version.view')->completeMatch();
        Route::get('versions/:id', 'admin.Versions/read')->middleware(RbacCheck::class, 'version.view')->pattern(['id' => '\d+']);
        Route::post('versions', 'admin.Versions/create')->middleware(RbacCheck::class, 'version.upload')->completeMatch();
        Route::post('apps/:id/upload', 'admin.Versions/upload')->middleware(RbacCheck::class, 'version.upload')->pattern(['id' => '\d+']);
        Route::put('versions/:id', 'admin.Versions/update')->middleware(RbacCheck::class, 'version.upload')->pattern(['id' => '\d+']);
        Route::delete('versions/:id', 'admin.Versions/delete')->middleware(RbacCheck::class, 'version.upload')->pattern(['id' => '\d+']);
        Route::post('versions/:id/publish', 'admin.Versions/publish')->middleware(RbacCheck::class, 'version.publish')->pattern(['id' => '\d+']);
        Route::post('versions/:id/pause', 'admin.Versions/pause')->middleware(RbacCheck::class, 'version.publish')->pattern(['id' => '\d+']);
        Route::post('versions/:id/rollback', 'admin.Versions/rollback')->middleware(RbacCheck::class, 'version.rollback')->pattern(['id' => '\d+']);

        // 发布任务
        Route::get('releases', 'admin.Releases/index')->middleware(RbacCheck::class, 'version.view')->completeMatch();
        Route::post('releases', 'admin.Releases/create')->middleware(RbacCheck::class, 'version.publish')->completeMatch();
        Route::put('releases/:id', 'admin.Releases/update')->middleware(RbacCheck::class, 'version.publish')->pattern(['id' => '\d+']);
        Route::post('releases/:id/stop', 'admin.Releases/stop')->middleware(RbacCheck::class, 'version.publish')->pattern(['id' => '\d+']);

        // 用户
        Route::get('users', 'admin.Users/index')->middleware(RbacCheck::class, 'user.view')->completeMatch();
        Route::get('users/:id', 'admin.Users/read')->middleware(RbacCheck::class, 'user.view')->pattern(['id' => '\d+']);
        Route::post('users/:id/disable', 'admin.Users/disable')->middleware(RbacCheck::class, 'user.view')->pattern(['id' => '\d+']);
        Route::post('users/:id/enable', 'admin.Users/enable')->middleware(RbacCheck::class, 'user.view')->pattern(['id' => '\d+']);

        // 设备
        Route::get('devices', 'admin.Devices/index')->middleware(RbacCheck::class, 'device.view')->completeMatch();
        Route::get('devices/:id', 'admin.Devices/read')->middleware(RbacCheck::class, 'device.view')->pattern(['id' => '\d+']);

        // 反馈
        Route::get('feedbacks', 'admin.Feedbacks/index')->middleware(RbacCheck::class, 'feedback.handle')->completeMatch();
        Route::get('feedbacks/:id', 'admin.Feedbacks/read')->middleware(RbacCheck::class, 'feedback.handle')->pattern(['id' => '\d+']);
        Route::put('feedbacks/:id', 'admin.Feedbacks/update')->middleware(RbacCheck::class, 'feedback.handle')->pattern(['id' => '\d+']);

        // 工单
        Route::get('tickets', 'admin.Tickets/index')->middleware(RbacCheck::class, 'ticket.handle')->completeMatch();
        Route::post('tickets', 'admin.Tickets/create')->middleware(RbacCheck::class, 'ticket.handle')->completeMatch();
        Route::get('tickets/:id', 'admin.Tickets/read')->middleware(RbacCheck::class, 'ticket.handle')->pattern(['id' => '\d+']);
        Route::put('tickets/:id', 'admin.Tickets/update')->middleware(RbacCheck::class, 'ticket.handle')->pattern(['id' => '\d+']);

        // 渠道
        Route::get('channels', 'admin.Channels/index')->middleware(RbacCheck::class, 'app.view')->completeMatch();
        Route::post('channels', 'admin.Channels/create')->middleware(RbacCheck::class, 'app.edit')->completeMatch();
        Route::put('channels/:id', 'admin.Channels/update')->middleware(RbacCheck::class, 'app.edit')->pattern(['id' => '\d+']);
        Route::delete('channels/:id', 'admin.Channels/delete')->middleware(RbacCheck::class, 'app.edit')->pattern(['id' => '\d+']);

        // 崩溃日志
        Route::get('crashes', 'admin.Crashes/index')->middleware(RbacCheck::class, 'device.view')->completeMatch();

        // 统计
        Route::get('downloads', 'admin.Stats/downloads')->middleware(RbacCheck::class, 'stat.view')->completeMatch();
        Route::get('updates', 'admin.Stats/updates')->middleware(RbacCheck::class, 'stat.view')->completeMatch();
        Route::get('stats/versions', 'admin.Stats/versions')->middleware(RbacCheck::class, 'stat.view')->completeMatch();
        Route::get('stats/platforms', 'admin.Stats/platforms')->middleware(RbacCheck::class, 'stat.view')->completeMatch();
        Route::get('stats/channels', 'admin.Stats/channels')->middleware(RbacCheck::class, 'stat.view')->completeMatch();
        Route::get('stats/feedbacks', 'admin.Stats/feedbacks')->middleware(RbacCheck::class, 'stat.view')->completeMatch();

        // 系统设置
        Route::get('admins', 'admin.System/admins')->middleware(RbacCheck::class, 'system.setting')->completeMatch();
        Route::post('admins', 'admin.System/createAdmin')->middleware(RbacCheck::class, 'system.setting')->completeMatch();
        Route::put('admins/:id', 'admin.System/updateAdmin')->middleware(RbacCheck::class, 'system.setting')->pattern(['id' => '\d+']);
        Route::get('roles', 'admin.System/roles')->middleware(RbacCheck::class, 'system.setting')->completeMatch();
        Route::get('permissions', 'admin.System/permissions')->middleware(RbacCheck::class, 'system.setting')->completeMatch();
        Route::put('roles/:id', 'admin.System/updateRole')->middleware(RbacCheck::class, 'system.setting')->pattern(['id' => '\d+']);
        Route::get('operation-logs', 'admin.System/operationLogs')->middleware(RbacCheck::class, 'system.setting')->completeMatch();

        // 公告
        Route::get('notices', 'admin.Notices/index')->middleware(RbacCheck::class, 'notice.view')->completeMatch();
        Route::post('notices', 'admin.Notices/create')->middleware(RbacCheck::class, 'notice.edit')->completeMatch();
        Route::put('notices/:id', 'admin.Notices/update')->middleware(RbacCheck::class, 'notice.edit')->pattern(['id' => '\d+']);
        Route::delete('notices/:id', 'admin.Notices/delete')->middleware(RbacCheck::class, 'notice.edit')->pattern(['id' => '\d+']);
    })->middleware(AuthAdmin::class);

    // ---------------- APP 端公开接口 ----------------
    // 检查更新（核心接口）
    Route::get('app/update/check', 'api.Update/check')->completeMatch();
    // 启用应用列表（官方首页）
    Route::get('app/list', 'api.App/list')->completeMatch();
    // 应用信息
    Route::get('app/info', 'api.App/info')->completeMatch();
    // 最新版本
    Route::get('app/version/latest', 'api.Version/latest')->completeMatch();
    // 历史版本
    Route::get('app/version/history', 'api.Version/history')->completeMatch();
    // 提交反馈
    Route::post('feedback/create', 'api.Feedback/create')->completeMatch();
    // 上传反馈附件
    Route::post('feedback/upload', 'api.Feedback/upload')->completeMatch();
    // Crash 上报
    Route::post('crash/report', 'api.Crash/report')->completeMatch();
    // 设备注册
    Route::post('device/register', 'api.Device/register')->completeMatch();
    // 设备心跳
    Route::post('device/heartbeat', 'api.Device/heartbeat')->completeMatch();
    // 公告列表
    Route::get('notice/list', 'api.Notice/list')->completeMatch();

    // ---------------- 前台用户（UCenter 账号同步） ----------------
    // 公开：注册 / 登录
    Route::post('user/register', 'api.User/register')->completeMatch();
    Route::post('user/login', 'api.User/login')->completeMatch();
    // 需登录
    Route::group('user', function () {
        Route::post('logout', 'api.User/logout')->completeMatch();
        Route::put('password', 'api.User/changePassword')->completeMatch();
        Route::put('email', 'api.User/changeEmail')->completeMatch();
        Route::get('me', 'api.User/me')->completeMatch();
        Route::post('sync/retry', 'api.User/retrySync')->completeMatch();
    })->middleware(AuthUser::class);
});

// ---------------- UCenter 服务器回调（前台公开，签名校验在控制器内） ----------------
Route::any('api/uc', 'api.UcenterNotify/index')->completeMatch();