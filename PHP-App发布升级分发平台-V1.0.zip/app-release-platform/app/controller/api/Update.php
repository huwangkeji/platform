<?php
declare (strict_types = 1);

namespace app\controller\api;

use app\BaseController;
use app\service\VersionDecisionService;
use think\response\Json;

/**
 * 更新检测（APP 端核心接口）
 */
class Update extends BaseController
{
    /**
     * 检查更新
     * GET /api/v1/app/update/check
     */
    public function check(): Json
    {
        $appCode = trim((string) $this->request->get('app_code', ''));
        if ($appCode === '') {
            return fail(10002, 'app_code 不能为空');
        }
        $app = $this->ensureApp($appCode);

        $params = [
            'version_code' => (int) $this->request->get('version_code', 0),
            'version_name' => (string) $this->request->get('version_name', ''),
            'platform'     => strtolower((string) $this->request->get('platform', 'android')),
            'os_version'   => (string) $this->request->get('os_version', ''),
            'architecture' => (string) $this->request->get('architecture', ''),
            'channel'      => (string) $this->request->get('channel', 'official'),
            'device_id'    => (string) $this->request->get('device_id', ''),
            'user_id'      => (string) $this->request->get('user_id', ''),
        ];

        $version = VersionDecisionService::decide($app, $params);
        VersionDecisionService::logCheck($app, $params, $version);

        return success(VersionDecisionService::response($version, $params['version_code']));
    }
}