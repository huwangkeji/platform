<?php
declare (strict_types = 1);

namespace app\controller\admin;

use app\BaseController;
use think\facade\Db;
use think\response\Json;

/**
 * 仪表盘：核心数据 + 趋势 + 图表
 */
class Dashboard extends BaseController
{
    /**
     * 核心统计
     */
    public function index(): Json
    {
        $today    = date('Y-m-d') . ' 00:00:00';
        $monthAgo = date('Y-m-d H:i:s', strtotime('-30 days'));

        $apps = (int) Db::name('apps')->count();
        $versions = (int) Db::name('app_versions')->count();
        $devices  = (int) Db::name('devices')->count();

        $grayVersions = (int) Db::name('app_versions')->where('status', 'gray')->count();
        $rollbackVersions = (int) Db::name('app_versions')->where('status', 'rollback')->count();

        $todayDownloads = (int) Db::name('download_logs')->where('created_at', '>=', $today)->count();
        $todayUpdates   = (int) Db::name('update_logs')->where('created_at', '>=', $today)->count();
        $todayFeedback  = (int) Db::name('feedbacks')->where('created_at', '>=', $today)->count();

        $pendingFeedbacks = (int) Db::name('feedbacks')->whereIn('status', ['pending', 'open', 'processing'])->count();
        $pendingTickets   = (int) Db::name('tickets')->whereIn('status', ['pending', 'processing', 'dev_pending', 'dev_processing', 'test_pending'])->count();
        $activeDevices    = (int) Db::name('devices')->where('last_active_at', '>=', $monthAgo)->count();
        $todayCrashes     = (int) Db::name('crash_reports')->where('created_at', '>=', $today)->count();

        return success([
            'apps'             => $apps,
            'versions'         => $versions,
            'devices'          => $devices,
            'gray_versions'    => $grayVersions,
            'rollback_versions'=> $rollbackVersions,
            'today_downloads'  => $todayDownloads,
            'today_updates'    => $todayUpdates,
            'today_feedbacks'  => $todayFeedback,
            'pending_feedbacks'=> $pendingFeedbacks,
            'pending_tickets'  => $pendingTickets,
            'active_devices'   => $activeDevices,
            'today_crashes'    => $todayCrashes,
        ]);
    }

    /**
     * 近30天 下载/升级 趋势
     */
    public function trend(): Json
    {
        $days = min(90, max(7, (int) $this->request->get('days', 30)));
        $since = date('Y-m-d 00:00:00', strtotime('-' . ($days - 1) . ' days'));

        $downloads = Db::name('download_logs')->where('created_at', '>=', $since)->select()->toArray();
        $updates   = Db::name('update_logs')->where('created_at', '>=', $since)->select()->toArray();

        $dc = [];
        $uc = [];
        foreach ($downloads as $r) {
            $d = substr((string) $r['created_at'], 0, 10);
            $dc[$d] = ($dc[$d] ?? 0) + 1;
        }
        foreach ($updates as $r) {
            $d = substr((string) $r['created_at'], 0, 10);
            $uc[$d] = ($uc[$d] ?? 0) + 1;
        }

        $dates = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $dates[] = date('Y-m-d', strtotime('-' . $i . ' days'));
        }

        $trend = array_map(function ($d) use ($dc, $uc) {
            return [
                'date'      => $d,
                'downloads' => $dc[$d] ?? 0,
                'updates'   => $uc[$d] ?? 0,
            ];
        }, $dates);

        return success(['days' => $days, 'trend' => $trend]);
    }

    /**
     * 图表：平台/渠道/版本/反馈 分布
     */
    public function charts(): Json
    {
        // 平台分布（下载）
        $platforms = Db::name('download_logs')
            ->field('platform, COUNT(*) AS total')
            ->group('platform')
            ->select()->toArray();
        $platformTotal = array_sum(array_column($platforms, 'total')) ?: 1;

        // 渠道分布（下载）
        $channels = Db::name('download_logs')
            ->field('channel_code, COUNT(*) AS total')
            ->whereNotNull('channel_code')
            ->group('channel_code')
            ->select()->toArray();

        // 设备版本分布
        $versionDist = Db::name('devices')
            ->field('app_version, COUNT(*) AS total')
            ->whereNotNull('app_version')
            ->where('app_version', '<>', '')
            ->group('app_version')
            ->select()->toArray();
        $versionTotal = array_sum(array_column($versionDist, 'total')) ?: 1;

        // 反馈类型分布
        $feedbackTypes = Db::name('feedbacks')
            ->field('type, COUNT(*) AS total')
            ->group('type')
            ->select()->toArray();

        return success([
            'platforms' => array_map(function ($p) use ($platformTotal) {
                return ['name' => (string) $p['platform'], 'value' => (int) $p['total'], 'percent' => round((int) $p['total'] / $platformTotal * 100, 1)];
            }, $platforms),
            'channels' => $channels,
            'versions' => array_map(function ($v) use ($versionTotal) {
                return ['name' => (string) $v['app_version'], 'value' => (int) $v['total'], 'percent' => round((int) $v['total'] / $versionTotal * 100, 1)];
            }, $versionDist),
            'feedback_types' => $feedbackTypes,
        ]);
    }
}