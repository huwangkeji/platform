<?php
declare (strict_types = 1);

namespace app\controller\admin;

use app\BaseController;
use think\facade\Db;
use think\response\Json;

/**
 * 统计报表
 */
class Stats extends BaseController
{
    /**
     * 下载统计：按应用汇总 + 近N天趋势
     */
    public function downloads(): Json
    {
        $appId = (int) $this->request->get('app_id', 0);
        $days  = min(90, max(1, (int) $this->request->get('days', 7)));
        $since = date('Y-m-d 00:00:00', strtotime('-' . ($days - 1) . ' days'));

        $query = Db::name('download_logs')->where('created_at', '>=', $since);
        if ($appId > 0) {
            $query->where('app_id', $appId);
        }
        $rows = $query->select()->toArray();

        $byApp = [];
        $byDay = [];
        foreach ($rows as $r) {
            $appKey = (int) $r['app_id'];
            $byApp[$appKey] = ($byApp[$appKey] ?? 0) + 1;
            $d = substr((string) $r['created_at'], 0, 10);
            $byDay[$d] = ($byDay[$d] ?? 0) + 1;
        }

        $appNames = Db::name('apps')->column('name', 'id');
        $appStat  = [];
        foreach ($byApp as $appKey => $cnt) {
            $appStat[] = ['app_id' => $appKey, 'app_name' => $appNames[$appKey] ?? '', 'downloads' => $cnt];
        }
        usort($appStat, fn ($a, $b) => $b['downloads'] - $a['downloads']);

        $dates = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime('-' . $i . ' days'));
            $dates[] = ['date' => $d, 'downloads' => $byDay[$d] ?? 0];
        }

        return success([
            'days'     => $days,
            'total'    => count($rows),
            'by_app'   => $appStat,
            'by_day'   => $dates,
        ]);
    }

    /**
     * 升级检测统计
     */
    public function updates(): Json
    {
        $appId = (int) $this->request->get('app_id', 0);
        $days  = min(90, max(1, (int) $this->request->get('days', 7)));
        $since = date('Y-m-d 00:00:00', strtotime('-' . ($days - 1) . ' days'));

        $query = Db::name('update_logs')->where('created_at', '>=', $since);
        if ($appId > 0) {
            $query->where('app_id', $appId);
        }
        $rows = $query->select()->toArray();

        $byDay = [];
        $byVer = [];
        foreach ($rows as $r) {
            $d = substr((string) $r['created_at'], 0, 10);
            $byDay[$d] = ($byDay[$d] ?? 0) + 1;
            $nv = (string) $r['new_version'];
            if ($nv !== '') {
                $byVer[$nv] = ($byVer[$nv] ?? 0) + 1;
            }
        }

        $dates = [];
        for ($i = $days - 1; $i >= 0; $i--) {
            $d = date('Y-m-d', strtotime('-' . $i . ' days'));
            $dates[] = ['date' => $d, 'updates' => $byDay[$d] ?? 0];
        }
        $verStat = [];
        foreach ($byVer as $ver => $cnt) {
            $verStat[] = ['version' => $ver, 'checks' => $cnt];
        }
        usort($verStat, fn ($a, $b) => $b['checks'] - $a['checks']);

        return success(['days' => $days, 'total' => count($rows), 'by_day' => $dates, 'by_version' => $verStat]);
    }

    /**
     * 版本占比（当前设备安装版本分布，全局维度）
     */
    public function versions(): Json
    {
        $query = Db::name('devices')
            ->field('app_version, COUNT(*) AS total')
            ->whereNotNull('app_version')
            ->where('app_version', '<>', '');
        $rows  = $query->group('app_version')->select()->toArray();
        $total = array_sum(array_column($rows, 'total')) ?: 1;

        $data = array_map(function ($r) use ($total) {
            return [
                'version' => (string) $r['app_version'],
                'count'   => (int) $r['total'],
                'percent' => round((int) $r['total'] / $total * 100, 1),
            ];
        }, $rows);
        usort($data, fn ($a, $b) => $b['count'] - $a['count']);

        return success(['total_devices' => (int) $total, 'list' => $data]);
    }

    /**
     * 平台占比（下载）
     */
    public function platforms(): Json
    {
        $appId = (int) $this->request->get('app_id', 0);
        $query = Db::name('download_logs')->field('platform, COUNT(*) AS total');
        if ($appId > 0) {
            $query->where('app_id', $appId);
        }
        $rows  = $query->group('platform')->select()->toArray();
        $total = array_sum(array_column($rows, 'total')) ?: 1;

        return success([
            'total' => (int) $total,
            'list'  => array_map(function ($r) use ($total) {
                return ['platform' => (string) $r['platform'], 'count' => (int) $r['total'], 'percent' => round((int) $r['total'] / $total * 100, 1)];
            }, $rows),
        ]);
    }

    /**
     * 渠道占比（下载）
     */
    public function channels(): Json
    {
        $appId = (int) $this->request->get('app_id', 0);
        $query = Db::name('download_logs')->field('channel_code, COUNT(*) AS total')->whereNotNull('channel_code');
        if ($appId > 0) {
            $query->where('app_id', $appId);
        }
        $rows  = $query->group('channel_code')->select()->toArray();
        $total = array_sum(array_column($rows, 'total')) ?: 1;

        $data = array_map(function ($r) use ($total) {
            return ['channel' => (string) $r['channel_code'], 'count' => (int) $r['total'], 'percent' => round((int) $r['total'] / $total * 100, 1)];
        }, $rows);
        usort($data, fn ($a, $b) => $b['count'] - $a['count']);

        return success(['total' => (int) $total, 'list' => $data]);
    }

    /**
     * 反馈统计（类型分布 + 状态分布）
     */
    public function feedbacks(): Json
    {
        $appId = (int) $this->request->get('app_id', 0);
        $q1 = Db::name('feedbacks')->field('type, COUNT(*) AS total')->group('type');
        $q2 = Db::name('feedbacks')->field('status, COUNT(*) AS total')->group('status');
        if ($appId > 0) {
            $q1->where('app_id', $appId);
            $q2->where('app_id', $appId);
        }
        return success([
            'by_type'  => $q1->select()->toArray(),
            'by_status'=> $q2->select()->toArray(),
        ]);
    }
}