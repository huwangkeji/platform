<?php
declare (strict_types = 1);

namespace app\common;

/**
 * 当前请求管理员上下文（由 AuthAdmin 中间件写入）
 * 所有读取方均位于 AuthAdmin 保护的 admin 路由组内，保证已被正确设置
 */
class AdminContext
{
    private static array $admin = [];
    private static bool $loaded = false;

    public static function set(array $admin): void
    {
        self::$admin  = $admin;
        self::$loaded = true;
    }

    public static function id(): int
    {
        return self::$loaded ? (int) (self::$admin['id'] ?? 0) : 0;
    }

    public static function admin(): array
    {
        return self::$admin;
    }

    public static function isSuper(): bool
    {
        return self::$loaded && !empty(self::$admin['roles']) && in_array('super_admin', self::$admin['roles'], true);
    }
}